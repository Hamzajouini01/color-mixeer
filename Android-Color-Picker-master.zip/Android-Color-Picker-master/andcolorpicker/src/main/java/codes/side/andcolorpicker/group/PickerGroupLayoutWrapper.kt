package codes.side.andcolorpicker.group

import android.view.View

// TODO: Wrap ready-to-use layouts and PickerGroups here
class PickerGroupLayoutWrapper(private var view: View) {
  init {
  }
}
