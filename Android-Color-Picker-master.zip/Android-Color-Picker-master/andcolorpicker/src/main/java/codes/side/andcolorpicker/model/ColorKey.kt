package codes.side.andcolorpicker.model

enum class ColorKey {
  HSL,
  RGB,
  CMYK,
  LAB
}
