package codes.side.andcolorpicker.app.fragment

import androidx.fragment.app.Fragment
import codes.side.andcolorpicker.app.R

class CMYKSeekBarGithubSampleFragment : Fragment(R.layout.fragment_cmyk_seek_bar_github_sample)
