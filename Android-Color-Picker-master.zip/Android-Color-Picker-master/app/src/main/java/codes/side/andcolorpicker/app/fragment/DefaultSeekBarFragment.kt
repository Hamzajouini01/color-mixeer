package codes.side.andcolorpicker.app.fragment

import androidx.fragment.app.Fragment
import codes.side.andcolorpicker.app.R

class DefaultSeekBarFragment : Fragment(R.layout.fragment_default_seek_bar)
