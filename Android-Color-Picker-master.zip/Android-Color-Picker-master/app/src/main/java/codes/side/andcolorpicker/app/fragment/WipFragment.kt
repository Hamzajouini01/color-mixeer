package codes.side.andcolorpicker.app.fragment

import androidx.fragment.app.Fragment
import codes.side.andcolorpicker.app.R

class WipFragment : Fragment(R.layout.fragment_wip)
